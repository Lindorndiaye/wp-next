<?php
/**
 * Plugin Name: Newsletter Endpoint
 * Description: Endpoint personnalisé pour recevoir les emails de newsletter depuis Next.js
 * Version: 1.0
 */

// Enregistrer un endpoint REST API personnalisé
add_action('rest_api_init', function () {
    register_rest_route('custom/v1', '/newsletter', array(
        'methods' => 'POST',
        'callback' => 'handle_newsletter_subscription',
        'permission_callback' => '__return_true', // Public endpoint
    ));
});

function handle_newsletter_subscription($request) {
    // Récupérer l'email depuis le body
    $email = sanitize_email($request->get_param('email'));
    
    if (empty($email)) {
        // Essayer depuis formData
        $body = $request->get_body();
        parse_str($body, $params);
        $email = isset($params['EMAIL']) ? sanitize_email($params['EMAIL']) : '';
    }
    
    if (empty($email) || !is_email($email)) {
        return new WP_Error('invalid_email', 'Email invalide', array('status' => 400));
    }
    
    // Vérifier si l'email existe déjà
    $existing = get_posts(array(
        'post_type' => 'subscriber',
        'post_status' => 'any',
        'meta_query' => array(
            array(
                'key' => 'email',
                'value' => $email,
                'compare' => '='
            )
        ),
        'posts_per_page' => 1
    ));
    
    if (!empty($existing)) {
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Cet email est déjà enregistré',
            'id' => $existing[0]->ID,
        ), 200);
    }
    
    // Créer un nouveau subscriber
    $post_id = wp_insert_post(array(
        'post_title' => $email,
        'post_type' => 'subscriber',
        'post_status' => 'publish',
        'meta_input' => array(
            'email' => $email,
            'date_subscribed' => current_time('mysql'),
        ),
    ));
    
    if (is_wp_error($post_id)) {
        return new WP_Error('creation_failed', 'Erreur lors de la création: ' . $post_id->get_error_message(), array('status' => 500));
    }
    
    return new WP_REST_Response(array(
        'success' => true,
        'message' => 'Email enregistré avec succès',
        'id' => $post_id,
    ), 200);
}
